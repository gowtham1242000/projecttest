module.exports = (sequelize, DataTypes) => {
  return sequelize.define("Product", {
    productId: { type: DataTypes.STRING, unique: true },
    name: DataTypes.STRING,
    category: DataTypes.STRING,
    unitPrice: DataTypes.FLOAT,
  });
};
