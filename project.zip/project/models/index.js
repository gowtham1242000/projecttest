const { Sequelize, DataTypes } = require("sequelize");
const config = require("../config");
const sequelize = new Sequelize(config.db);

const Customer = require("./customer")(sequelize, DataTypes);
const Product = require("./product")(sequelize, DataTypes);
const Order = require("./order")(sequelize, DataTypes);

Customer.hasMany(Order);
Order.belongsTo(Customer);
Product.hasMany(Order);
Order.belongsTo(Product);

module.exports = { sequelize, Customer, Product, Order };

