module.exports = (sequelize, DataTypes) => {
  return sequelize.define("Order", {
    orderId: { type: DataTypes.STRING, unique: true },
    region: DataTypes.STRING,
    dateOfSale: DataTypes.DATEONLY,
    quantity: DataTypes.INTEGER,
    discount: DataTypes.FLOAT,
    shippingCost: DataTypes.FLOAT,
    paymentMethod: DataTypes.STRING,
  });
};
