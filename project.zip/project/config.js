module.exports = {
  db: {
    database: "salesdb",
    username: "postgres",
    password: "password@123",
    host: "localhost",
    dialect: "postgres",
  },
};
