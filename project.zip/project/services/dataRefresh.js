const { loadCSV } = require("./dataLoader");
async function refreshDataJob() {
  try {
    console.log("Refreshing data...");
    await loadCSV("./etc/ec/code/sales.csv");
    console.log("Data refresh completed.");
  } catch (err) {
    console.error("Data refresh failed:", err);
  }
}
module.exports = { refreshDataJob };
