const fs = require("fs");
const csv = require("csv-parser");
const { Customer, Product, Order } = require("../models");

async function loadCSV(filePath) {
  const results = [];
  return new Promise((resolve, reject) => {
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => results.push(data))
      .on("end", async () => {
        for (const row of results) {
          const [customer] = await Customer.findOrCreate({
            where: { customerId: row["Customer ID"] },
            defaults: {
              name: row["Customer Name"],
              email: row["Customer Email"],
              address: row["Customer Address"],
            },
          });

          const [product] = await Product.findOrCreate({
            where: { productId: row["Product ID"] },
            defaults: {
              name: row["Product Name"],
              category: row["Category"],
              unitPrice: parseFloat(row["Unit Price"]),
            },
          });

          await Order.upsert({
            orderId: row["Order ID"],
            region: row["Region"],
            dateOfSale: row["Date of Sale"],
            quantity: parseInt(row["Quantity Sold"]),
            discount: parseFloat(row["Discount"]),
            shippingCost: parseFloat(row["Shipping Cost"]),
            paymentMethod: row["Payment Method"],
            CustomerId: customer.id,
            ProductId: product.id,
          });
        }
        resolve("CSV Loaded");
      });
  });
}

module.exports = { loadCSV };

