const express = require("express");
const { totalRevenueByCategory } = require("../controllers/analyticsController");
const { refreshDataJob } = require("../services/dataRefresh");

const router = express.Router();

router.get("/revenue-by-category", totalRevenueByCategory);
router.post("/refresh-data", async (req, res) => {
  try {
    await refreshDataJob();
    res.json({ message: "Data refreshed" });
  } catch (err) {
    res.status(500).json({ error: "Failed to refresh data" });
  }
});

module.exports = router;
