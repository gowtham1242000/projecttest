const express = require("express");
const bodyParser = require("body-parser");
const cron = require("node-cron");
const { refreshDataJob } = require("./services/dataRefresh");
const routes = require("./routes");
const { sequelize } = require("./models");

const app = express();
app.use(bodyParser.json());

app.use("/api", routes);

sequelize.sync().then(() => {
  console.log("Database synced");
  app.listen(3000, () => console.log("Server started on port 3000"));
});

cron.schedule("0 0 * * *", refreshDataJob);
