const { Order, Product } = require("../models");
const { Op } = require("sequelize");

async function totalRevenueByCategory(req, res) {
  const { startDate, endDate } = req.query;
  try {
    const orders = await Order.findAll({
      where: {
        dateOfSale: {
          [Op.between]: [startDate, endDate],
        },
      },
      include: [Product],
    });

    const revenueMap = {};
    for (const order of orders) {
      const revenue =
        order.quantity * order.Product.unitPrice * (1 - order.discount);
      const category = order.Product.category;
      revenueMap[category] = (revenueMap[category] || 0) + revenue;
    }

    res.json(revenueMap);
  } catch (err) {
    res.status(500).json({ error: "Failed to calculate revenue" });
  }
}

module.exports = { totalRevenueByCategory };
